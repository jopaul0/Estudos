package com.lanchonete.controller;

import com.lanchonete.dao.LancheDAO;
import com.lanchonete.model.Lanche;

import java.util.List;

public class LancheController {

    private final LancheDAO lancheDAO;

    public LancheController() {
        this.lancheDAO = new LancheDAO();
    }

    public void adicionarLanche(Lanche lanche) {
        if (lanche.getPreco().doubleValue() <= 0) {
            System.out.println("Erro: O preço do lanche deve ser positivo.");
            return;
        }
        lancheDAO.inserir(lanche);
        System.out.println("Lanche adicionado com sucesso! ID: " + lanche.getId());
    }

    public List<Lanche> listarLanches() {
        return lancheDAO.listarTodos();
    }

    public void atualizarLanche(Lanche lanche) {
        lancheDAO.atualizar(lanche);
        System.out.println("Lanche ID " + lanche.getId() + " atualizado com sucesso!");
    }

    public void removerLanche(int id) {
        lancheDAO.deletar(id);
        System.out.println("Lanche ID " + id + " removido com sucesso!");
    }
}