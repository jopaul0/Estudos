package com.lanchonete.dao;

import com.lanchonete.factory.ConnectionFactory;
import com.lanchonete.model.Lanche;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LancheDAO {

    public void inserir(Lanche lanche) {
        String sql = "INSERT INTO lanches (nome, descricao, preco) VALUES (?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, lanche.getNome());
            stmt.setString(2, lanche.getDescricao());
            stmt.setBigDecimal(3, lanche.getPreco());

            stmt.executeUpdate();

            // Opcional: Obter o ID gerado (para o Model)
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    lanche.setId(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao inserir lanche: " + e.getMessage());
        }
    }

    public List<Lanche> listarTodos() {
        String sql = "SELECT * FROM lanches";
        List<Lanche> lanches = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Lanche lanche = new Lanche(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descricao"),
                        rs.getBigDecimal("preco")
                );
                lanches.add(lanche);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar lanches: " + e.getMessage());
        }
        return lanches;
    }

    public void atualizar(Lanche lanche) {
        String sql = "UPDATE lanches SET nome = ?, descricao = ?, preco = ? WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, lanche.getNome());
            stmt.setString(2, lanche.getDescricao());
            stmt.setBigDecimal(3, lanche.getPreco());
            stmt.setInt(4, lanche.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar lanche: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM lanches WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erro ao deletar lanche: " + e.getMessage());
        }
    }
}