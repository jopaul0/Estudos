package com.lanchonete.view;

import com.lanchonete.controller.LancheController;
import com.lanchonete.model.Lanche;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Vector;

public class LancheView extends JFrame {

    private final LancheController controller;
    private final DefaultTableModel tableModel;

    private JTextField txtNome;
    private JTextField txtDescricao;
    private JTextField txtPreco;
    private JTable lanchesTable;
    private JButton btnAdicionar;
    private JButton btnAtualizar;
    private JButton btnRemover;

    public LancheView() {
        this.controller = new LancheController();

        setTitle("CRUD de Lanches - Lanchonete Simples");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] colunas = {"ID", "Nome", "Descrição", "Preço"};
        tableModel = new DefaultTableModel(colunas, 0);
        lanchesTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(lanchesTable);
        add(scrollPane, BorderLayout.CENTER);

        popularTabela();

        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBorder(BorderFactory.createTitledBorder("Gerenciar Lanches"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Margens
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtNome = new JTextField(20);
        txtDescricao = new JTextField(20);
        txtPreco = new JTextField(10);

        adicionarComponente(painelFormulario, new JLabel("Nome:"), gbc, 0, 0, 1);
        adicionarComponente(painelFormulario, txtNome, gbc, 1, 0, 2);

        adicionarComponente(painelFormulario, new JLabel("Descrição:"), gbc, 0, 1, 1);
        adicionarComponente(painelFormulario, txtDescricao, gbc, 1, 1, 2);

        adicionarComponente(painelFormulario, new JLabel("Preço:"), gbc, 0, 2, 1);
        adicionarComponente(painelFormulario, txtPreco, gbc, 1, 2, 1);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));

        btnAdicionar = new JButton("Adicionar");
        btnAtualizar = new JButton("Atualizar");
        btnRemover = new JButton("Remover");

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnRemover);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3;
        painelFormulario.add(painelBotoes, gbc);

        add(painelFormulario, BorderLayout.NORTH);
        adicionarListeners();
    }

    private void adicionarComponente(JPanel painel, Component componente, GridBagConstraints gbc, int x, int y, int width) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = width;
        painel.add(componente, gbc);
    }

    private void adicionarListeners() {
        btnAdicionar.addActionListener(e -> adicionarLanche());

        btnRemover.addActionListener(e -> removerLanche());

        btnAtualizar.addActionListener(e -> atualizarLanche());

        lanchesTable.getSelectionModel().addListSelectionListener(e -> {
            int linha = lanchesTable.getSelectedRow();
            if (linha >= 0) {
                // ID está na coluna 0, mas pegamos o Model
                txtNome.setText(tableModel.getValueAt(linha, 1).toString());
                txtDescricao.setText(tableModel.getValueAt(linha, 2).toString());
                txtPreco.setText(tableModel.getValueAt(linha, 3).toString().replace(',', '.'));
            }
        });
    }

    // Método para carregar a tabela com dados do banco
    private void popularTabela() {
        tableModel.setRowCount(0);

        List<Lanche> lanches = controller.listarLanches();
        for (Lanche lanche : lanches) {
            Vector<Object> linha = new Vector<>();
            linha.add(lanche.getId());
            linha.add(lanche.getNome());
            linha.add(lanche.getDescricao());
            linha.add(String.format("%.2f", lanche.getPreco()));
            tableModel.addRow(linha);
        }
    }

    private void adicionarLanche() {
        try {
            String nome = txtNome.getText();
            String descricao = txtDescricao.getText();
            // Garante que o separador decimal seja o ponto
            BigDecimal preco = new BigDecimal(txtPreco.getText().replace(',', '.'));

            Lanche novoLanche = new Lanche(nome, descricao, preco);
            controller.adicionarLanche(novoLanche);

            JOptionPane.showMessageDialog(this, "Lanche adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            limparCampos();
            popularTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao adicionar lanche: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void atualizarLanche() {
        int linhaSelecionada = lanchesTable.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um lanche na tabela para atualizar.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int id = (int) tableModel.getValueAt(linhaSelecionada, 0);
            String nome = txtNome.getText();
            String descricao = txtDescricao.getText();
            BigDecimal preco = new BigDecimal(txtPreco.getText().replace(',', '.'));

            Lanche lancheAtualizado = new Lanche(id, nome, descricao, preco);
            controller.atualizarLanche(lancheAtualizado);

            JOptionPane.showMessageDialog(this, "Lanche atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            limparCampos();
            popularTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar lanche: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removerLanche() {
        int linhaSelecionada = lanchesTable.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um lanche na tabela para remover.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirmacao = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja remover este lanche?", "Confirmar Remoção", JOptionPane.YES_NO_OPTION);

        if (confirmacao == JOptionPane.YES_OPTION) {
            try {
                int id = (int) tableModel.getValueAt(linhaSelecionada, 0);
                controller.removerLanche(id);

                JOptionPane.showMessageDialog(this, "Lanche removido com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                limparCampos();
                popularTabela();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao remover lanche: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limparCampos() {
        txtNome.setText("");
        txtDescricao.setText("");
        txtPreco.setText("");
        lanchesTable.clearSelection();
    }

    // Método main
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LancheView view = new LancheView();
            view.setVisible(true);
        });
    }
}